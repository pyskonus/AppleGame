""" This is the main module of the AppleGame """

import A_menu
import pygame
pygame.init()
A_menu.menu_main()
pygame.quit()
